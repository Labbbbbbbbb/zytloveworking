#ifndef WTR_CAN_H
#define WTR_CAN_H

#include "wtr_dji.h"
#include "can.h"

HAL_StatusTypeDef CANFilterInit(CAN_HandleTypeDef *hcan);

#endif
