/*
 * @Author: ZYT
 * @Date: 2024-07-20 21:34:11
 * @LastEditors: ZYT
 * @LastEditTime: 2024-07-20 21:34:12
 * @FilePath: \Gantry_Trial\UserCode\Upper\Upper_StateMachine\Light_fury_state.h
 * @Brief: 
 * 
 * Copyright (c) 2024 by zyt, All Rights Reserved. 
 */
#ifndef __LIGHT_FURY_STATE_H__
#define __LIGHT_FURY_STATE_H__

#include "UpperStart.h"

void StateMachine_Start(void);
#endif // __LIGHT_FURY_STATE_H__