/*
 * @Author: ZYT
 * @Date: 2024-07-19 12:51:59
 * @LastEditors: ZYT
 * @LastEditTime: 2024-07-19 12:51:59
 * @FilePath: \Gantry_Trial\UserCode\Upper\Protect\reset.h
 * @Brief: 
 * 
 * Copyright (c) 2024 by zyt, All Rights Reserved. 
 */
#ifndef __RESET_H__
#define __RESET_H__

#include "UpperStart.h"

void Reset_Start(void);

#endif // __RESET_H__
